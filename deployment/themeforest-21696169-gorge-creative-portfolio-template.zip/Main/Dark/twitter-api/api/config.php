<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '5y21GL0Jtk0wFJMM3cAYpluWu');
    define('CONSUMER_SECRET', 'KWzcf4SydTkBFZ8rQBeT5WQpDkC0otbCSAAsC0e8k9K3mSzypW');

    // User Access Token
    define('ACCESS_TOKEN', '132139793-yGoYZ3viEbMgTqDVHxK9eKQaHoHr2R7gWteJTvC3');
    define('ACCESS_SECRET', 'MmWNpix7YejHgJJ6LIOvHrlpSPVN7jQe2IJN4bW06SpbZ');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));